package com.springboot.demo.service;

import com.springboot.demo.entity.Employee;

import java.util.List;

public interface EmployeeService {

	List<Employee> getAllEmployees();
	Employee saveEmployee(Employee employee);

	Employee getEmployeeById(Long id);
	Employee updateEmployee(Employee student);
	void deleteEmployeeById(Long id);
	
}
