package com.springboot.demo.serviceImpl;

import com.springboot.demo.entity.Employee;
import com.springboot.demo.repository.employeeRepository;
import com.springboot.demo.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	private employeeRepository employeeRepository;
	
	public EmployeeServiceImpl(employeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
    }

	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee getEmployeeById(Long id) {
		return employeeRepository.findById(id).get();
	}

	@Override
	public Employee updateEmployee(Employee student) {
		return employeeRepository.save(student);
	}

	@Override
	public void deleteEmployeeById(Long id) {
		employeeRepository.deleteById(id);

	}
}
